// Set only after implementing an authenticated server endpoint that creates a
// hosted payment session from the user's server-side order. No secret keys here.
window.AccountPaymentConfig = Object.freeze({
  sessionEndpoint: '',
  allowedCheckoutHosts: []
});
