(() => {
'use strict';
const translations = {"Payment":"الدفع","Local preview — accounts, orders and payments are not connected to a server yet.": "نسخة معاينة محلية — وظائف الحسابات والطلبات والدفع غير متصلة بخادم بعد.", "Admin Dashboard": "لوحة الإدارة", "Language": "تغيير اللغة", "My Account": "حسابي", "Sign Out": "تسجيل الخروج", "How to start selling": "كيف تبدأ البيع؟", "Three steps to open your verified store": "ثلاث خطوات لفتح متجرك الموثّق", "We build shopper trust by verifying every seller before their products appear on the marketplace.": "نحافظ على ثقة المتسوقين عبر التحقق من هوية كل بائع قبل نشر منتجاته على المنصة.", "Create your account": "أنشئ حسابك", "Sign up with your email and confirm your sign-in with a verification code in seconds.": "سجّل بالبريد الإلكتروني وأكّد الدخول برمز التحقق في ثوانٍ.", "Verify your identity": "وثّق هويتك", "Verify your email and phone, upload your national ID, then wait for approval.": "أكّد بريدك وجوالك، ارفع صورة الهوية الوطنية، ثم بانتظار موافقة الإدارة.", "List your products": "اعرض منتجاتك", "Once verified, add photos and prices to your products. They will appear in your store and the marketplace catalog.": "بعد التوثيق أضف منتجاتك بصور وأسعار، وستظهر في متجرك وفي كتالوج السوق.", "Get started for free": "ابدأ الآن مجانًا", "Best sellers": "الأكثر طلبًا", "Selected accounts and digital offers": "حسابات وعروض رقمية مختارة", "View all offers": "عرض كل العروض", "Add 1191 to cart": "أضف 1191 إلى السلة", "Ask about 1191": "تواصل بخصوص 1191", "Social Media Accounts": "حسابات التواصل الاجتماعي", "Verified sellers": "بائعون موثّقون", "Shop from stores with verified owners": "تسوّق من متاجر تم التحقق من أصحابها", "All sellers": "كل البائعين", "Visit account": "زيارة الحساب", "Visit your account to track orders, sales and balance, and manage your personal details.": "انتقل إلى حسابك لمتابعة طلباتك ومبيعاتك ورصيدك وإدارة بياناتك الشخصية.", "150+ accounts": "+150 حسابًا", "80+ services": "+80 خدمة", "120+ products": "+120 منتجًا", "Digital Services": "الخدمات الرقمية", "Games and Subscriptions": "الألعاب والاشتراكات", "Exclusive offers": "عروض حصرية", "Get the latest updates from marketplace sellers": "اشترك ليصلك كل جديد من بائعي السوق", "Subscribe for new products and discounts from verified stores. No spam.": "سجّل بريدك الإلكتروني لتصلك أحدث المنتجات والخصومات من المتاجر الموثّقة قبل الجميع، دون أي رسائل مزعجة.", "Email address": "البريد الإلكتروني", "Subscribe now": "اشترك الآن", "Main navigation": "التنقل الرئيسي", "Account - Home": "Account - الصفحة الرئيسية", "Account logo": "شعار Account", "Account avatar": "صورة الحساب", "Mobile navigation": "قائمة الجوال", "Digital apps on a smartphone": "واجهات تطبيقات رقمية على هاتف ذكي", "Instagram": "إنستغرام", "Facebook": "فيسبوك", "WhatsApp": "واتساب", "TikTok": "تيك توك", "Account | Marketplace with ID-verified sellers": "Account | سوق إلكتروني ببائعين موثّقين بالهوية الوطنية", "Account marketplace: shop from ID-verified sellers or verify your account and sell products in your own store.": "سوق Account الإلكتروني: اشترِ من بائعين موثّقين بالهوية الوطنية، أو وثّق حسابك واعرض منتجاتك في متجر خاص بك.", "Trusted online marketplace": "سوق إلكتروني موثوق", "TRUSTED MARKET": "سوق موثوق", "Home": "الرئيسية", "Shop": "المتجر", "Categories": "الفئات", "Games & Subscriptions": "الألعاب والاشتراكات", "Sellers": "البائعون", "Help Center": "مركز المساعدة", "Sell": "بيع", "Settings": "الإعدادات", "My Orders": "طلباتي", "Withdraw": "سحب الرصيد", "Cart": "السلة", "Menu": "القائمة", "Verify Account": "توثيق الحساب", "Store Disputes": "نزاعات المتجر", "Contact Us": "تواصل معنا", "The Trusted Account Market": "سوق الحسابات الموثوق", "Buy and sell with confidence… sellers verified by national ID": "اشترِ وبِع بثقة… بائعون موثّقون بالهوية الوطنية", "On Account every seller verifies their national ID before listing products, so you shop from real, certified stores. Create your store in minutes and start selling, or browse products from trusted sellers.": "في Account يوثّق كل بائع هويته الوطنية قبل عرض منتجاته، لتتسوق من متاجر موثوقة. أنشئ متجرك خلال دقائق وابدأ البيع، أو تصفّح منتجات البائعين الموثّقين.", "Browse Products": "تصفّح المنتجات", "Start Selling Now": "ابدأ البيع الآن", "Verified Sellers": "بائعون موثّقون", "Products": "منتج", "24h": "24 ساعة", "Fast Shipping": "شحن سريع", "Every store listed here has a verified owner.": "كل متجر هنا له مالك موثّق.", "Shop by category": "تسوّق حسب الفئة", "Choose the digital product you need": "اختر المنتج الرقمي الذي تحتاجه", "We organised the market into three main categories to get you there fast: social accounts, digital services, and games.": "رتّبنا السوق في ثلاث فئات رئيسية: حسابات التواصل والخدمات الرقمية والألعاب.", "Verified, ready-made accounts for social and messaging platforms.": "حسابات موثّقة وجاهزة لمنصات التواصل والمراسلة.", "Browse list": "تصفّح القائمة", "Design, editing, development and account management from trusted freelancers.": "تصميم وتحرير وتطوير وإدارة حسابات من مستقلين موثوقين.", "Games, in-game top-ups and subscriptions at competitive prices.": "ألعاب وشحن واشتراكات بأسعار تنافسية.", "A trusted marketplace bringing together sellers verified by national ID to showcase and sell their products safely, in an easy and reliable shopping experience.": "سوق موثوق يجمع بائعين موثّقين بالهوية الوطنية لعرض منتجاتهم وبيعها بأمان، ضمن تجربة تسوّق سهلة وموثوقة.", "All Products": "كل المنتجات", "Start Selling": "ابدأ البيع", "Contact": "التواصل", "Every seller on the platform is verified by national ID.": "كل بائع في المنصة موثّق بالهوية الوطنية.", "© 2026 Account. All rights reserved.": "© 2026 Account. جميع الحقوق محفوظة.", "A safe and trusted shopping experience.": "تجربة تسوّق آمنة وموثوقة."};
const rate = 3.75;
let language = 'en';
const originals = new WeakMap();
const attributes = new WeakMap();
function amountFromSar(value, lang = language) {
 const amount = Number(value);
 if (!Number.isFinite(amount)) return '';
 const number = new Intl.NumberFormat('en-US', {minimumFractionDigits:2, maximumFractionDigits:2}).format(lang === 'ar' ? amount : amount / rate);
 return lang === 'ar' ? number + ' ريال' : '$' + number;
}
function render(root = document.body) {
 const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
 let node;
 while ((node = walker.nextNode())) {
  if (node.parentElement.closest('script,style,select,[data-price-sar],[data-mc-price]')) continue;
  if (!originals.has(node)) originals.set(node, node.nodeValue);
  const source = originals.get(node), key = source.trim();
  node.nodeValue = language === 'ar' && translations[key] ? source.replace(key, translations[key]) : source;
 }
 root.querySelectorAll('[aria-label],[alt],[placeholder]').forEach(el => {
  if (el.closest('#langSwitch')) return;
  if (!attributes.has(el)) attributes.set(el, Object.fromEntries(['aria-label','alt','placeholder'].filter(a => el.hasAttribute(a)).map(a => [a, el.getAttribute(a)])));
  for (const [a, source] of Object.entries(attributes.get(el))) el.setAttribute(a, language === 'ar' ? translations[source] || source : source);
 });
 root.querySelectorAll('[data-price-sar],[data-mc-price]').forEach(el => {
  const base = el.getAttribute('data-price-sar') ?? el.getAttribute('data-mc-price');
  el.textContent = amountFromSar(base);
  el.setAttribute('data-display-currency', language === 'ar' ? 'SAR' : 'USD');
  el.setAttribute('dir', 'ltr');
 });
}
function applyLanguage(lang) {
 language = lang === 'ar' ? 'ar' : 'en';
 document.documentElement.lang = language;
 document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
 document.getElementById('languageSelect').value = language;
 render();
 document.title = language === 'ar' ? 'Account | سوق إلكتروني ببائعين موثّقين' : 'Account | Marketplace with ID-verified sellers';
 try { localStorage.setItem('app_lang', language); } catch (_) {}
}
window.AccountCurrency = Object.freeze({formatSar:amountFromSar, sarPerUsd:rate, refresh:() => render()});
document.getElementById('languageSelect').addEventListener('change', event => applyLanguage(event.target.value));
let saved = 'en';
try { saved = localStorage.getItem('app_lang') || 'en'; } catch (_) {}
applyLanguage(saved);
})();
