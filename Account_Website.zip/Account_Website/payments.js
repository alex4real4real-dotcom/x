(() => {
'use strict';
const config = window.AccountPaymentConfig || {};
const button = document.getElementById('continue');
const status = document.getElementById('status');
const select = document.getElementById('language');
const words = {
 ar: {back:'العودة للمتجر',title:'طريقة الدفع',intro:'اختر طريقة الدفع لطلبك.',card:'بطاقة ائتمانية',continue:'متابعة الدفع',status:'الدفع غير مفعّل حاليًا. ستتوفر الخدمة بعد إكمال إعداد بوابة الدفع.',note:'سيظهر المبلغ النهائي وعملة الخصم في صفحة بوابة الدفع قبل التأكيد.',error:'تعذّر بدء الدفع. لم يتم تأكيد أي عملية دفع.',loading:'جارٍ فتح صفحة الدفع…'},
 en: {back:'Back to store',title:'Payment method',intro:'Choose a payment method for your order.',card:'Credit card',continue:'Continue to payment',status:'Payments are currently unavailable. Payment gateway setup is pending.',note:'The final amount and charge currency will appear on the payment provider’s page before confirmation.',error:'Unable to start checkout. No payment has been confirmed.',loading:'Opening secure checkout…'}
};
let lang='ar';try{lang=localStorage.getItem('app_lang')==='en'?'en':'ar'}catch(_){}
function render(){document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr';select.value=lang;for(const id of ['back','title','intro','card','continue','note'])document.getElementById(id).textContent=words[lang][id];status.textContent=words[lang].status;button.disabled=!config.sessionEndpoint;}
select.addEventListener('change',()=>{lang=select.value;try{localStorage.setItem('app_lang',lang)}catch(_){}render()});
button.addEventListener('click',async()=>{
 if(!config.sessionEndpoint)return;
 button.disabled=true;status.textContent=words[lang].loading;
 try{
  const endpoint=new URL(config.sessionEndpoint,location.origin);
  if(endpoint.origin!==location.origin)throw Error('Invalid endpoint');
  const response=await fetch(endpoint,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({method:document.querySelector('[name="method"]:checked').value,language:lang})});
  if(!response.ok)throw Error('Checkout unavailable');
  const session=await response.json();const url=new URL(session.checkoutUrl);
  if(url.protocol!=='https:'||!(config.allowedCheckoutHosts||[]).includes(url.hostname))throw Error('Invalid checkout URL');
  location.assign(url.href);
 }catch(_){status.textContent=words[lang].error;button.disabled=false;}
});render();
})();
